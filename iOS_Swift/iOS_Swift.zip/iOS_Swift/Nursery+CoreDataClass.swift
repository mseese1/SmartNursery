// Project:     raspi_MQTT
// Author:      Michael Seese
// Date:        3/26/18
//
//  Nursery+CoreDataClass.swift
//  raspi_MQTT
//
//  Created by OWNER1 on 4/1/18.
//  Copyright © 2018 MJS90935. All rights reserved.
//

import Foundation
import CoreData

@objc(Nursery)
public class Nursery: NSManagedObject {

}
