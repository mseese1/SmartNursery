// Project:     raspi_MQTT
// Author:      Michael Seese
// Date:        3/26/18
//
//  Nursery+CoreDataProperties.swift
//  raspi_MQTT
//
//  Created by OWNER1 on 4/1/18.
//  Copyright © 2018 MJS90935. All rights reserved.
//

import Foundation
import CoreData


extension Nursery {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Nursery>
    {
        return NSFetchRequest<Nursery>(entityName: "Nursery")
    }

    @NSManaged public var humidity: Float
    @NSManaged public var light_state: String?
    @NSManaged public var room: String?
    @NSManaged public var temperature: Int32

    convenience init(managedObjectContext:NSManagedObjectContext, humidity: Float, light_state: String, temperature: Int32, room: String)
    {
        self.init(context: managedObjectContext)
        
        self.humidity       = humidity
        self.light_state    = light_state
        self.temperature    = temperature
        self.room           = room
    }
    
    
}
