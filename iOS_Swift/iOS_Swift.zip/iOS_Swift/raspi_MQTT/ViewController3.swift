// Project:     raspi_MQTT
// Author:      Michael Seese
// Date:        3/26/18
//
//            **** This is for the Adjustments Scene  ****
//
// To do:     --Create specific functions for publishing topics, and their respective switches
//                                                                              *******done 4/22
//            --Possibly Change text color depending on values.

//
//
// Updates:   --4/22/2018 Added simple publish functions for each switch and outlets for each label
//
//  ViewController3.swift
//  raspi_MQTT
//
//  Created by OWNER1 on 4/7/18.
//  Copyright © 2018 MJS90935. All rights reserved.
//

import UIKit
import CocoaMQTT
import CoreData

class ViewController3: UIViewController
{
    
    
    @IBOutlet weak var lblHeater: UILabel!
    @IBOutlet weak var lblHumidifier: UILabel!
    @IBOutlet weak var lblLights: UILabel!
    
    //let mqttClient = CocoaMQTT(clientID: "iOS-Device3", host:"192.168.1.242", port: 1883)
    let lightStatusDefaultsKey = "lightStatusDefaultsKey"
    var mqttClient: CocoaMQTT!
    
    
    func save(lightStatus: String)
    {
        let userDefaults = UserDefaults.standard
        userDefaults.set(lightStatus, forKey: lightStatusDefaultsKey)
        userDefaults.synchronize()
    }
    
    func setUpMQTT()
    {
        
        mqttClient = CocoaMQTT(clientID: "iOS Controller", host: "192.168.1.242", port: 1883)
        mqttClient.username = "test"
        mqttClient.password = "public"
        mqttClient.willMessage = CocoaMQTTWill(topic:"/will", message:"dieout")
        mqttClient.keepAlive = 60
        mqttClient.connect()
    }
    
    
    //adjusts heat control on/off
    @IBAction func swHeat(_ sender: UISwitch)
    {
        if sender.isOn
        {
            //publishes a message to rpi/gpio topic to turn on the gpio switch
            mqttClient.publish("rpi/gpio", withString: "HEATLEDON")
        }
        else
        {
            //publishes a message to rpi/gpio topic to turn off the gpio switch
            mqttClient.publish("rpi/gpio", withString: "HEATLEDOFF")
        }
        
    }
    
    
    //adjusts humidity control on/off
    @IBAction func swHumid(_ sender: UISwitch)
    {
        if sender.isOn
        {
            //publishes a message to rpi/gpio topic to turn on the gpio switch
            mqttClient.publish("rpi/gpio", withString: "HUMIDLEDON")
        }
        else
        {
            //publishes a message to rpi/gpio topic to turn off the gpio switch
            mqttClient.publish("rpi/gpio", withString: "HUMIDLEDOFF")
        }
    }
    
    
    //adjusts light control on/off
    @IBAction func swLights(_ sender: UISwitch)
    {
        
        if sender.isOn
        {
            //publishes a message to rpi/gpio topic to turn on the gpio switch
            mqttClient.publish("rpi/gpio", withString: "LIGHTSON")
            save(lightStatus: "ON")
        }
        else
        {
            //publishes a message to rpi/gpio topic to turn off the gpio switch
            mqttClient.publish("rpi/gpio", withString: "LIGHTSOFF")
            save(lightStatus: "OFF")
        }
        
    }
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        setUpMQTT()
        
        // Do Something
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // Do more things

}
