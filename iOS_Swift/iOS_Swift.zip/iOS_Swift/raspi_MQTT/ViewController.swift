// Project:     raspi_MQTT
// Author:      Michael Seese
// Date:        3/26/18
//
//                              *******************  For the initial landing scene ****
//  ViewController.swift
//  raspi_MQTT
//    192.168.1.242:1883
//  Created by OWNER1 on 3/27/18.
//  Copyright © 2018 MJS90935. All rights reserved.
//

import UIKit
import CoreData
import CocoaMQTT

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource
{

    //@IBOutlet weak var tvRooms: UITableView!
    @IBOutlet weak var tvRooms: UITableView!
    
    let defaults = UserDefaults.standard
    let serverAddressKey = "serverAddressKey"
    
    func save(serverKey: String)
    {
        let userDefaults = UserDefaults.standard
        userDefaults.set(serverKey, forKey: serverAddressKey)
        userDefaults.synchronize()
    }
    
    var mqttClient = CocoaMQTT(clientID: "iOS Device", host: "0.0.0.0", port: 1883)

    let managedObjectContext = (UIApplication.shared.delegate
        as! AppDelegate).persistentContainer.viewContext
    let cellReuseIdentifier = "cell1"
    
    var crArray:[Credentials] = [Credentials]()
    var count:Int = 0

    
    
    @IBAction func btnSetRoom(_ sender: UIButton)
    {
        let alertController = UIAlertController(title: "Set Room",
                                                message: "",
                                                preferredStyle: UIAlertControllerStyle.alert)
        
        // add the textField to the Alert. Create a closuer to handle the configuration
        alertController.addTextField(configurationHandler: {(textField: UITextField!) in
            textField.placeholder="Room"
            textField.keyboardType=UIKeyboardType.default
            //            textField.secureTextEntry = true    // password entry
        })

        let defaultAction = UIAlertAction(
            title: "Select",
            style: UIAlertActionStyle.default,
            handler: {(alertAction: UIAlertAction!) in
                // get the input from the alert controller
                let room: String = (alertController.textFields![0] ).text!
                let roomSet = CoreDataHelper.getCredentialsByRoom(managedObjectContext: self.managedObjectContext, room: room)
                self.mqttClient.host = (roomSet?.server_address)!
                self.save(serverKey: (roomSet?.server_address)!)
        })

        let cancelAction = UIAlertAction(
            title: "Cancel",
            style: UIAlertActionStyle.cancel,
            handler:nil)
        
        // add the action to the Alert
        alertController.addAction(defaultAction)
        alertController.addAction(cancelAction)

        // display the Alert
        present(alertController, animated: true, completion: nil)
        
    }
    
    
    

    @IBAction func btnAdd(_ sender: UIButton)
    {
        // create an Alert with a textFields for all ContactBusiness fields
        let alertController = UIAlertController(title: "Add Credentials",
                                                message: "",
                                                preferredStyle: UIAlertControllerStyle.alert)
        
        // add the textField to the Alert. Create a closuer to handle the configuration
        alertController.addTextField(configurationHandler: {(textField: UITextField!) in
            textField.placeholder="Room"
            //            textField.secureTextEntry = true    // password entry
        })
        
        alertController.addTextField(configurationHandler: {(textField: UITextField!) in
            textField.placeholder="Password"
            textField.isSecureTextEntry = true
            textField.keyboardType=UIKeyboardType.default
        })
        
        alertController.addTextField(configurationHandler: {(textField: UITextField!) in
            textField.placeholder="Server Address"
            textField.keyboardType=UIKeyboardType.phonePad
        })
        
        
        // create a default action for the Alert
        let defaultAction = UIAlertAction(
            title: "Ok",
            style: UIAlertActionStyle.default,
            handler: {(alertAction: UIAlertAction!) in
                // get the input from the alert controller
                let room: String = (alertController.textFields![0] ).text!
                let password: String = (alertController.textFields![1] ).text!
                let server_address: String = (alertController.textFields![2] ).text!
                
                // add Contact to the managedOBject
                _ = Credentials(managedObjectContext: self.managedObjectContext,
                                room: room, password: password, server_address: server_address)
                
                // save the managedObject
                CoreDataHelper.addCredentials(managedObjectContext: self.managedObjectContext)
                
                // get all Contacts from CoreData
                self.crArray = CoreDataHelper.getAllCredentials(managedObjectContext: self.managedObjectContext)
                
                // reload the data into the TableView
                self.tvRooms.reloadData()
        })
        
        
        let cancelAction = UIAlertAction(
            title: "Cancel",
            style: UIAlertActionStyle.cancel,
            handler:nil)
        
        // add the action to the Alert
        alertController.addAction(defaultAction)
        alertController.addAction(cancelAction)
        
        // generate test data
        gernerateTestData(alertController: alertController)
        
        
        
        // display the Alert
        present(alertController, animated: true, completion: nil)
        
    }

    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        //uncomment to test either
        //CoreDataTest.testNursery(managedObjectContext: managedObjectContext)
        //CoreDataTest.testCredentials(managedObjectContext: managedObjectContext)
        
        //use to clear coredata for credentials.
        //CoreDataHelper.deleteAllCredentials(managedObjectContext: managedObjectContext)
        
        tvRooms.delegate    = self
        tvRooms.dataSource  = self
        crArray = CoreDataHelper.getAllCredentials(managedObjectContext: managedObjectContext)
    
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return crArray.count
    }
    
    // create a cell for each table view row
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        // create a new cell if needed or reuse an old one
        let cell:CredentialsTableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath) as! CredentialsTableViewCell
     
        // set the text from the array into the cells labels
        cell.lblRoom.text = crArray[indexPath.row].room
        cell.Password.text = "****"//crArray[indexPath.row].password
        cell.lblServer_Address.text = crArray[indexPath.row].server_address
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        
        // get the tableViewCell
        let cell = tableView.cellForRow(at: indexPath) as! CredentialsTableViewCell
        
        // print the text property in the label in the tableViewCell
        print("TableView tapped = \(cell.lblRoom.text!), \(cell.Password.text!), \(cell.lblServer_Address.text!), Pos: \(indexPath.row)")
        
        //update the credentials...
        updateCredentials(room: cell.lblRoom.text!)
        
        //remove the selected entry
        self.crArray.remove(at: indexPath.row)
        
        // reload the tableView
        self.tvRooms.reloadData()
        
        // remove from CoreData
        CoreDataHelper.deleteCredentialsByRoom(managedObjectContext: self.managedObjectContext, room: cell.lblRoom.text!)

    }

    //duplicate this twice;  once for updating status on adjustments page for status of appliances, and once for adjusting actual information/data
    func updateCredentials(room:String)
    {
        
        // get the credntials by the room name
        let crObject = CoreDataHelper.getCredentialsByRoom(managedObjectContext: managedObjectContext, room: room)!
    
        // create an Alert with a textFields for all Credentials fields
        let alertController = UIAlertController(title: "Udpate \(room)",
            message: "",
            preferredStyle: UIAlertControllerStyle.alert)
        
        alertController.addTextField(configurationHandler: {(textField: UITextField!) in
            textField.text = crObject.password
            textField.isSecureTextEntry = true
            textField.keyboardType=UIKeyboardType.default
        })
        
        alertController.addTextField(configurationHandler: {(textField: UITextField!) in
            textField.text = crObject.server_address
            textField.keyboardType=UIKeyboardType.phonePad
        })

        
        // create a default action for the Alert
        let defaultAction = UIAlertAction(
            title: "Ok",
            style: UIAlertActionStyle.default,
            handler: {(alertAction: UIAlertAction!) in

                let password = (alertController.textFields![0]).text!
                let server_address = (alertController.textFields![1]).text!
                
                _ = Credentials(managedObjectContext: self.managedObjectContext,
                                room: room, password: password, server_address: server_address)
                
                // save the managedObject
                CoreDataHelper.addCredentials(managedObjectContext: self.managedObjectContext)
                
                // get all Credentials from CoreData
                self.crArray = CoreDataHelper.getAllCredentials(managedObjectContext: self.managedObjectContext)
                
                // reload the data into the TableView
                self.tvRooms.reloadData()
        })
        
        let cancelAction = UIAlertAction(
            title: "Cancel",
            style: UIAlertActionStyle.cancel,
            handler:nil)
        
        // add the action to the Alert
        alertController.addAction(defaultAction)
        alertController.addAction(cancelAction)
        
        // display the Alert
        present(alertController, animated: true, completion: nil)
    }

    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    //When the Connect button is pressed
    @IBAction func connectButton(_ sender: UIButton)
    {
        mqttClient.connect()
    }

    @IBAction func btnDisconnect(_ sender: UIButton)
    {
        mqttClient.disconnect()

    }

    func gernerateTestData(alertController:UIAlertController)
    {
        // increment count
        count += 1
        // get the textfields and assign test data
        (alertController.textFields![0]).text = "Room\(count)"
        (alertController.textFields![1]).text = "Password\(count)"
        (alertController.textFields![2]).text = "Server Address\(count)"

    }
    
    func deleteCredentials(room:String, position:Int)
    {
        // create the AlertController
        let alertController = UIAlertController(title: "Delete",
                                                message: room + ": Confirm Delete",
                                                preferredStyle: UIAlertControllerStyle.alert)
        
        // create a default action button
        let deleteAction = UIAlertAction(title: "Delete",
                                         style: UIAlertActionStyle.default,
                                         handler: {(alertAction: UIAlertAction!) in
                                            // remove from array
                                            self.crArray.remove(at: position)
                                            // reload the tableView
                                            self.tvRooms.reloadData()
                                            // remove from CoreData
                                            CoreDataHelper.deleteCredentialsByRoom(managedObjectContext: self.managedObjectContext, room: room)
        })
        
        let cancelAction = UIAlertAction(title: "Cancel",
                                         style: UIAlertActionStyle.cancel,
                                         handler: nil)
        
        // Add the actions to the Alert
        alertController.addAction(deleteAction)
        alertController.addAction(cancelAction)
        
        // present or display the Alert
        present(alertController, animated: true, completion: nil)
    }



    
}

extension String
{
    
    subscript (i: Int) -> Character
    {
        return self[index(startIndex, offsetBy: i)]
    }
    
    subscript (i: Int) -> String
    {
        return String(self[i] as Character)
    }
    
    subscript (r: Range<Int>) -> String
    {
        let start = index(startIndex, offsetBy: r.lowerBound)
        let end = index(startIndex, offsetBy: r.upperBound)
        return self[Range(start ..< end)]
    }
}
