// Project:     raspi_MQTT
// Author:      Michael Seese
// Date:        3/26/18
// File:        CoreDataHelper.swift
//  raspi_MQTT
//  Copyright © 2018 MJS90935. All rights reserved.
//

import Foundation

import CoreData


class CoreDataHelper
{
    // add Credentials Entity
    static func addCredentials(managedObjectContext:NSManagedObjectContext)
    {
        do
        {
            try managedObjectContext.save()
        }
        catch
        {
            
        }
    }
    
    // deletes all items in the credentials entity
    static func deleteAllCredentials(managedObjectContext:NSManagedObjectContext)
    {
        // create a fetch request for the entity Credentials
        let fetch = NSFetchRequest<NSFetchRequestResult>(entityName: "Credentials")
        // create a batch delete request
        let request = NSBatchDeleteRequest(fetchRequest: fetch)
        do
        {
            // execute the request
            try managedObjectContext.execute(request)
            
        }
        catch let error
        {
            print(error.localizedDescription)
        }
    }
    
    // returns all credential entries as array of objects
    static func getAllCredentials(managedObjectContext:NSManagedObjectContext)->[Credentials]
    {
        // create empty array of credential objects
        var data:[Credentials] = [Credentials]()
        do
        {
            // create the fetch request
            let fetchRequest:NSFetchRequest<Credentials> = Credentials.fetchRequest()
            
            // create sort descriptor and assign it to fetch request
            let roomSort = NSSortDescriptor(key: "room", ascending: true)
            fetchRequest.sortDescriptors = [roomSort]
            
            data = try managedObjectContext.fetch(fetchRequest)
            
        }
        catch let error
        {
            print(error.localizedDescription)
        }
        return data
    }
    
    // get a Credential set by its name and return the object
    static func getCredentialsByRoom(managedObjectContext:NSManagedObjectContext, room:String)->Credentials?
    {
        var data:[Credentials] = [Credentials]()
        do
        {
            // create the request from the credentials entity
            let request: NSFetchRequest<Credentials> = Credentials.fetchRequest()
            
            // assign the predicate
            request.predicate = NSPredicate(format: "(room = %@)", room)
            
            // fetch the data
            data = try managedObjectContext.fetch(request)
            
            if data.count > 0
            {
                return data[0]
            }
            else
            {
                print("No Match")
            }
        }
        catch let error
        {
            print(error.localizedDescription)
        }
        // no match
        return nil
    }
    
    // delete a Credentials object found by name
    static func deleteCredentialsByRoom(managedObjectContext:NSManagedObjectContext, room:String)
    {
        var data:[Credentials] = [Credentials]()
        do
        {
            // create the request
            let request: NSFetchRequest<Credentials> = Credentials.fetchRequest()
            
            // assign the predicate
            request.predicate = NSPredicate(format: "(room = %@)", room)
            
            // fetch the data
            data = try managedObjectContext.fetch(request)
            
            if data.count > 0
            {
                // delete the managed object
                managedObjectContext.delete(data[0])
                
                // save after delete. 
                try managedObjectContext.save()
            }
            else
            {
                print("No Match")
            }
        }
        catch let error
        {
            print(error.localizedDescription)
        }
    }
    
    
    // ********* Nursery Entity *****************
    // add contact to Nursery Entity
    static func addNursery(managedObjectContext:NSManagedObjectContext)
    {
        do
        {
            try managedObjectContext.save()
        }
        catch
        {
            
        }
    }
    
    // deletes all Nursery objects
    static func deleteAllNursery(managedObjectContext:NSManagedObjectContext)
    {
        // create a fetch request for the entity Nursery
        let fetch = NSFetchRequest<NSFetchRequestResult>(entityName: "Nursery")
        // create a batch delete request
        let request = NSBatchDeleteRequest(fetchRequest: fetch)
        do
        {
            // execute the request
            try managedObjectContext.execute(request)
            
        }
        catch let error
        {
            print(error.localizedDescription)
        }
    }
    
    // returns all Nuseries as array of objects
    static func getAllNursery(managedObjectContext:NSManagedObjectContext)->[Nursery]
    {
        // create empty array of Nursery objects
        var data:[Nursery] = [Nursery]()
        do
        {
            // create the fetch request
            let fetchRequest:NSFetchRequest<Nursery> = Nursery.fetchRequest()
            
            // create sort descriptor and assign it to fetch request
            let nameSort = NSSortDescriptor(key: "room", ascending: true)
            fetchRequest.sortDescriptors = [nameSort]
            
            data = try managedObjectContext.fetch(fetchRequest)
            
        }
        catch let error
        {
            print(error.localizedDescription)
        }
        return data
    }
    
    // get a Nursery by its room and return as object
    static func getNurseryByRoom(managedObjectContext:NSManagedObjectContext, room:String)->Nursery?
    {
        var data:[Nursery] = [Nursery]()
        do
        {
            // create the request from the Nursery entity
            let request: NSFetchRequest<Nursery> = Nursery.fetchRequest()
            
            // assign the predicate
            request.predicate = NSPredicate(format: "(room = %@)", room)
            
            // fetch the data
            data = try managedObjectContext.fetch(request)
            
            if data.count > 0
            {
                return data[0]
            }
            else
            {
                print("No Match")
            }
        }
        catch let error
        {
            print(error.localizedDescription)
        }
        // no match
        return nil
    }
    
    // delete a Nursery by room from the Nursery entity
    static func deleteNurseryByRoom(managedObjectContext:NSManagedObjectContext, room:String)
    {
        var data:[Nursery] = [Nursery]()
        do
        {
            // create the request
            let request: NSFetchRequest<Nursery> = Nursery.fetchRequest()
            
            // assign the predicate
            request.predicate = NSPredicate(format: "(room = %@)", room)
            
            // fetch the data
            data = try managedObjectContext.fetch(request)
            
            if data.count > 0
            {
                
                // delete the managed object
                managedObjectContext.delete(data[0])
                
                //save after delete.
                try managedObjectContext.save()
            }
            else
            {
                print("No Match")
            }
        }
        catch let error
        {
            print(error.localizedDescription)
        }
    }
}
