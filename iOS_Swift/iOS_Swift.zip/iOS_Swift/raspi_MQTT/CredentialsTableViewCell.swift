// Project:     raspi_MQTT
// Author:      Michael Seese
// Date:        3/26/18
//
//  CredentialsTableViewCell.swift -- simple custom table view cell
//  raspi_MQTT
//
//  Created by OWNER1 on 4/8/18.
//  Copyright © 2018 MJS90935. All rights reserved.
//

import UIKit

class CredentialsTableViewCell: UITableViewCell
{

    @IBOutlet weak var lblRoom: UILabel!
    @IBOutlet weak var Password: UILabel!
    @IBOutlet weak var lblServer_Address: UILabel!
    
    
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
