// Project:     raspi_MQTT
// Author:      Michael Seese
// Date:        3/26/18
//
//  TestCoreData.swift
//  raspi_MQTT
//
//  Created by OWNER1 on 4/1/18.
//  Copyright © 2018 MJS90935. All rights reserved.
//

import Foundation

import CoreData

class CoreDataTest
{
    // uncomment to test credentials
    static func testCredentials(managedObjectContext: NSManagedObjectContext)
    {
//        // delete all the items in the Friend entity
//        CoreDataHelper.deleteAllCredentials(managedObjectContext: managedObjectContext)
//        
//        // create ContactFriend managed objects
//        // Use _ = because we don't need to save the objects
//        // They are added to the managed object
//        _ = Credentials(managedObjectContext: managedObjectContext,room: "N1", password: "P1", server_address: "192.168.0.242")
//        _ = Credentials(managedObjectContext: managedObjectContext,room: "N2", password: "P2", server_address: "192.168.0.242")
//        _ = Credentials(managedObjectContext: managedObjectContext,room: "N3", password: "P3", server_address: "192.168.0.242")
//        _ = Credentials(managedObjectContext: managedObjectContext,room: "N4", password: "P4", server_address: "192.168.0.242")
//        
//        // call addContactFriend to add all managed objects to CoreData
//        CoreDataHelper.addCredentials(managedObjectContext: managedObjectContext)
        
        // list all items in Friend entity
        let list:[Credentials] = CoreDataHelper.getAllCredentials(managedObjectContext: managedObjectContext)
        
        // loop through the list and print each item
        print("\nTest getAllCredentials")
        for item in list
        {
            print("\(item.room), \(item.password!), \(item.server_address!)")
        }
//        
//        // test getCredendtialsByRoom
//        print("\nTest getCredentialsByRoom(\"N3\")")
//        let credentials:Credentials = CoreDataHelper.getCredentialsByRoom(managedObjectContext: managedObjectContext, room: "N3")!
//        print("\(credentials.room!), \(credentials.password!), \(credentials.server_address!)")
//
//        
//        // test deleteCredentialsFriendByRoom
//        print("\nTest deleteCredentialsByRoom(\"N3\")")
//        CoreDataHelper.deleteCredentialsByRoom(managedObjectContext: managedObjectContext, room: "N3")
//        
//        // list all items in Friend entity
//        let list1:[Credentials] = CoreDataHelper.getAllCredentials(managedObjectContext: managedObjectContext)
//        
//        // loop through the list and print each item
//        print("\nTest getAllCredentials()")
//        for item in list1
//        {
//            print("\(item.room!), \(item.password!), \(item.server_address!)")
//        }
    }
    
    static func testNursery(managedObjectContext: NSManagedObjectContext)
    {
        // delete all the items in the Nursery entity
                CoreDataHelper.deleteAllNursery(managedObjectContext: managedObjectContext)
        
        // create ContactBusiness managed objects
        // Use _ = because we don't need to save the objects
        // They are added to the managed object
                _ = Nursery(managedObjectContext: managedObjectContext,humidity: 34.6, light_state: "off", temperature: 76, room: "R1")
                _ = Nursery(managedObjectContext: managedObjectContext, humidity: 35.6, light_state: "on", temperature: 75, room: "R2")
                _ = Nursery(managedObjectContext: managedObjectContext, humidity: 36.6, light_state: "off", temperature: 74, room: "R3")
                _ = Nursery(managedObjectContext: managedObjectContext, humidity: 37.6, light_state: "on", temperature: 73, room: "R4")
        // call addContactBusiness to add all managed objects to CoreData
                CoreDataHelper.addNursery(managedObjectContext: managedObjectContext)
//
        // list all items in Business entity
        let list:[Nursery] = CoreDataHelper.getAllNursery(managedObjectContext: managedObjectContext)
        
        // loop through the list and print each item
        print("\nTest getAllNursery()")
        for item in list
        {
            print("\(item.room!), \(item.light_state!), \(item.temperature), \(item.humidity)")
        }
        
//                // test getNurseryByRoom
                print("\nTest getNurseryByRoom(\"R3\")")
                let nursery:Nursery = CoreDataHelper.getNurseryByRoom(managedObjectContext: managedObjectContext, room: "R3")!
                print("\(nursery.room!), \(nursery.light_state!), \(nursery.temperature), \(nursery.humidity)")
        
                // test deleteNurseryByRoom
                print("\nTest deleteNurseryByRoom(\"R3\")")
                CoreDataHelper.deleteNurseryByRoom(managedObjectContext: managedObjectContext, room: "R3")
        
                // list all items in Nursery entity
                let list1:[Nursery] = CoreDataHelper.getAllNursery(managedObjectContext: managedObjectContext)
        
                // loop through the list and print each item
                print("\nTest getAllNursery()")
                for item in list1
                {
                  print("\(item.room!), \(item.light_state!), \(item.temperature), \(item.humidity)")
                }
    }
}
 
