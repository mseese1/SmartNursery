// Project:     raspi_MQTT
// Author:      Michael Seese
// Date:        3/26/18
//
//            ******* For the Monitor Scene *****
//
// To do:     --Finish, and clean specific functions for subscribing to topics              ***DONE
//            --Set up refresh button to refresh values                                     ***DONE
//            --Possibly Change text color depending on values.                             ***DONE FOR LIGHTS
//            --Possibly add pressure value                                                 ***DONE
//            --Add update nursery function to update the sensory data using getnurserybyroom
//
//
//
// Updates:   --4/22/18 added/adjusted outlets for labels and textfields
//
//  ViewController2.swift
//  raspi_MQTT
//
//  Created by OWNER1 on 4/7/18.
//  Copyright © 2018 MJS90935. All rights reserved.
//



import UIKit
import CocoaMQTT

class ViewController2: UIViewController
{
    var mqtt: CocoaMQTT!
    
    //Text Field and Label outlets
    @IBOutlet weak var tfHumidity: UITextField!
    @IBOutlet weak var tfTemp: UITextField!
    @IBOutlet weak var tfPressure: UITextField!
    @IBOutlet weak var lblTemp: UILabel!
    @IBOutlet weak var lblHumidity: UILabel!
    @IBOutlet weak var lblLights: UILabel!
    @IBOutlet weak var lblPressure: UILabel!
    
    let defaults = UserDefaults.standard
    var mainHost = ""
    
    func setUpMQTT()
    {
        
        mqtt = CocoaMQTT(clientID: "iOS Monitor", host: "192.168.1.242", port: 1883)
        mqtt.username = "test"
        mqtt.password = "public"
        mqtt.willMessage = CocoaMQTTWill(topic:"/will", message:"dieout")
        mqtt.keepAlive = 60
        mqtt.connect()
        mqtt.delegate = self
        
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        setUpMQTT()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Prompts Raspberry Pi for temperature data and updates the appropriate text field
    @IBAction func btnRefresh(_ sender: UIButton)
    {
        mqtt.subscribe("rpi-temp")
        mqtt.publish("sensory", withString: "TEMP")
    }
    
    //Prompts Raspberry Pi for humidity data and updates the appropriate text field
    @IBAction func btnRefreshHumidity(_ sender: UIButton)
    {
        mqtt.subscribe("rpi-humid")
        mqtt.publish("sensory", withString: "HUMID")
    }
    
    //Prompts Raspberry Pi for barometric pressure data and updates the appropriate text field
    @IBAction func btnRefreshPressure(_ sender: UIButton)
    {
        mqtt.subscribe("rpi-press")
        mqtt.publish("sensory", withString: "PRESS")
    }

    //Prompts Raspberry Pi for temperature/humidity/pressure data, updates the log file and prompts the Raspberry Pi to upload the log to GCP
    @IBAction func btnUpdateLog(_ sender: UIButton)
    {
        mqtt.publish("sensory", withString: "UPDATELOG")
    }
    
    //Prompts Raspberry Pi for light status and updates the appropriate label
    @IBAction func btnCheckLights(_ sender: UIButton)
    {
       // mqtt.subscribe("rpi-lights")
        //mqtt.publish("sensory", withString: "CHECKLIGHTS")
        let lightStatus = defaults.value(forKey: "lightStatusDefaultsKey")

        if (String(describing: lightStatus).range(of: "ON") != nil)
        {
            lblLights.textColor = UIColor.yellow
        }
        else
        {
            lblLights.textColor = UIColor.black
        }
    }
    
    
}

extension ViewController2: CocoaMQTTDelegate {
    //Delegate for the MQTT client.  This allows for control of the MQTT protocol and data manipulation based on the topics subscribed and published to
    func mqtt(_ mqtt: CocoaMQTT, didConnect host: String, port: Int)
    {
        mqtt.subscribe("rpi-temp")
        mqtt.subscribe("rpi-humid")
        mqtt.subscribe("rpi-press")
        mqtt.subscribe("rpi-lights")
    }
    
    //This function dictates what happens to each message recieved based on the contents of the published message.  searches for a string within the message and updates the appropriate label or text field or reacts appropriately.
    func mqtt(_ mqtt: CocoaMQTT, didReceiveMessage message: CocoaMQTTMessage, id: UInt16 )
    {
        if message.string?.range(of:"C") != nil
        {
            if let msgString = message.string
            {
                tfTemp.text = msgString
            }
        }
       
        else if message.string?.range(of:"hPa") != nil
        {
            if let msgString = message.string
            {
                tfPressure.text = msgString
            }
        }
        
        else if message.string?.range(of:"%") != nil
        {
            if let msgString = message.string
            {
                tfHumidity.text = msgString
            }
        }
        
        else if message.string?.range(of:"OFF") != nil
        {
            lblLights.textColor = UIColor.black
        }
        
        else if message.string?.range(of:"ON") != nil
        {
            lblLights.textColor = UIColor.yellow
        }
    }
    
    // Other required methods for CocoaMQTTDelegate  That are for the most part useless for this project and thus left empty.
    func mqtt(_ mqtt: CocoaMQTT, didReceive trust: SecTrust, completionHandler: @escaping (Bool) -> Void)
    {
        completionHandler(true)
    }
    
    func mqtt(_ mqtt: CocoaMQTT, didConnectAck ack: CocoaMQTTConnAck) {
    }
    
    func mqtt(_ mqtt: CocoaMQTT, didPublishMessage message: CocoaMQTTMessage, id: UInt16) {
    }
    
    func mqtt(_ mqtt: CocoaMQTT, didPublishAck id: UInt16) {
    }
    
    func mqtt(_ mqtt: CocoaMQTT, didSubscribeTopic topic: String) {
    }
    
    func mqtt(_ mqtt: CocoaMQTT, didUnsubscribeTopic topic: String) {
    }
    
    func mqttDidPing(_ mqtt: CocoaMQTT) {
    }
    
    func mqttDidReceivePong(_ mqtt: CocoaMQTT) {
    }
    
    func mqttDidDisconnect(_ mqtt: CocoaMQTT, withError err: Error?) {
    }
    
    func _console(_ info: String) {
    }
}
