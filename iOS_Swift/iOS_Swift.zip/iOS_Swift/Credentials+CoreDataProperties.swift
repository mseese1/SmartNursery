// Project:     raspi_MQTT
// Author:      Michael Seese
// Date:        3/26/18
//
//  Credentials+CoreDataProperties.swift
//  raspi_MQTT
//
//  Created by OWNER1 on 4/1/18.
//  Copyright © 2018 MJS90935. All rights reserved.
//

import Foundation
import CoreData


extension Credentials {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Credentials> {
        return NSFetchRequest<Credentials>(entityName: "Credentials")
    }

    @NSManaged public var room: String?
    @NSManaged public var password: String?
    @NSManaged public var server_address: String?
    
    
    convenience init(managedObjectContext:NSManagedObjectContext, room: String, password: String, server_address: String)
    {
        self.init(context: managedObjectContext)
        
        self.room           = room
        self.password       = password
        self.server_address = server_address
    }

}
